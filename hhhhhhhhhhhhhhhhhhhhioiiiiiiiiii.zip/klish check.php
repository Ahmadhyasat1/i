• Hi sajad New Email ⚠️
•━•━•━•━•━•━•━•━•━•━•
- ❖ UserName : $username 
- ❖ Email : $email 
- ❖ Followers : $followers
- ❖ Following : $following
- ❖ Post : $posts 
•━•━•━•━•━•━•━•━•━•━•
• || @YYYhYY & @o4abot || • ⁦


± hi sir new email checked ±
•–~––~––~––~––~––~–•
.᪥. 𝑼𝒔𝒆𝒓𝑵𝒂𝒎𝒆 : $usernamw
.᪥. 𝑬𝒎𝒂𝒊𝒍 :  $email
.᪥. 𝑭𝒐𝒍𝒍𝒐𝒘𝒆𝒓𝒔 : $followers
.᪥. 𝑭𝒐𝒍𝒍𝒐𝒘𝒊𝒏𝒈  : $following
.᪥. 𝑽𝒆𝒓𝒊𝒇𝒊𝒆𝒅 : $verified
•–~––~––~––~––~––~–•
( @YYYhYY \✓/ @o4abot )



---------------------------------
" sajad new email ♻️⚠️
---------------------------------
∆ user ≈ $username 
∆ email → $email
∆ followers ≈ $followers
∆ following → $following
∆ time ≈ $time
∆ post → $posts
∆ verified ≈ $verified
---------------------------------
≠ @YYYhYY ≠ @o4abot ≠
---------------------------------